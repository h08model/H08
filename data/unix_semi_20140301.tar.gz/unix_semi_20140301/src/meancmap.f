      program meancmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
cto   convert annual/monthly/daily data to mean annual/monthly/daily data
cby   nhanasaki
con   6th Jan 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      implicit none
c parameter
      integer           nx
      integer           ny
      parameter        (nx=144)
      parameter        (ny=72)
c index
      integer           ix
      integer           iy
      integer           iyear
      integer           iyearmin
      integer           iyearmax
      integer           imon
      integer           imonmin
      integer           imonmax
      integer           iday
      integer           idaymin
      integer           idaymax
c temporary
      character*128     ctmp
c function
      integer           iargc
      integer           igetday
      integer           len_trim
c in
      real              rdat(nx,ny)
c out
      real              rout(nx,ny)
c files
      character*128     cdir
      character*128     cexp
      character*128     crun
      character*128     csuf
      character*128     cifname
      character*128     cofname
      integer           ilen
      character*128     clen
c option
      character*128     copt
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Get Arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      if(iargc().lt.7)then
        write(*,*) 'meancmap dir exp run yearmin yearmax suf opt'
        write(*,*) 'opt: yr for annual  0000'
        write(*,*) 'opt: mo for monthly 0100 - 1200'
        write(*,*) 'opt: dy for monthly 0101 - 1231'
        stop
      end if
c
      call getarg(1,cdir)
      call getarg(2,cexp)
      call getarg(3,crun)
      call getarg(4,ctmp)
      read(ctmp,*) iyearmin
      call getarg(5,ctmp)
      read(ctmp,*) iyearmax
      call getarg(6,csuf)
      call getarg(7,copt)
c
      ilen=len_trim(cdir)
      write(clen,*) ilen
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Loop
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      if(copt.eq.'yr')then
        imonmin=0
        imonmax=0
      else
        imonmin=1
        imonmax=12
      end if
      do imon=imonmin,imonmax
        if(copt.eq.'dy')then
          idaymin=1
          idaymax=igetday(1981,imon)
        else
          idaymin=0
          idaymax=0
        end if
        do iday=idaymin,idaymax
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Main
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c initialize array
          do iy=1,ny
            do ix=1,nx
              rout(ix,iy)=0.0
            end do
          end do
          do iyear=iyearmin,iyearmax
c read data
            write(cifname,'(a'//clen//',a4,a4,i4.4,i2.2,i2.2,a5)') 
     $      cdir,cexp,crun,iyear,imon,iday,csuf
            call read_binmat(rdat,nx,ny,15,cifname)
c            open(15,file=cifname,access='direct',status='old',recl=4*nx)
c            do iy=1,ny
c              read(15,rec=iy) (rdat(ix,iy),ix=1,nx)
c            end do
c            close(15)
c calclulation
            do iy=1,ny
              do ix=1,nx
                rout(ix,iy)=rout(ix,iy)+rdat(ix,iy)
              end do
            end do
          end do
c Get average
          do iy=1,ny
            do ix=1,nx
              rout(ix,iy)=rout(ix,iy)/(iyearmax-iyearmin+1)
            end do
          end do
c Write results
          write(cofname,'(a'//clen//',a4,a4,i4.4,i2.2,i2.2,a5)')
     $    cdir,cexp,crun,0,imon,iday,csuf 
          call read_binmat(rout,nx,ny,16,cofname)
c          open(16,file=cifname,access='direct',recl=4*nx)
c          do iy=1,ny
c            write(16,rec=iy) (rout(ix,iy),ix=1,nx)
c          end do
c          close(16)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
        end do
      end do
c
      end
