      program pointcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   pick up a value (lon,lat) in an array
cby   nhanasaki
con   13th Aug 2002
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx
      integer           ny
      real              plonmin
      real              plonmax
      real              platmin
      real              platmax
      parameter        (nx=144)
      parameter        (ny=72)
      parameter        (plonmin=-180.0)
      parameter        (plonmax=180.0)
      parameter        (platmin=-90.0)
      parameter        (platmax=90.0)
c index
      integer           ix
      integer           iy                        !! loop
c temporary
      character*128     ctmp             !! dummy
c function
      integer           iargc
c in
      real              rdat(nx,ny)      !! matrixpnt DATA
      real              rlon 
      real              rlat                        !! input coordinate
c local
      integer           ixpnt
      integer           iypnt                     !! matrixpnt coordinate
c file
      character*128     cifname          !! Input File NAME
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.3) then
        write(*,*) 'Usage: pointcmap Infile lon(deg) lat(deg)'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,ctmp)
      read(ctmp,*) rlon
      call getarg(3,ctmp)
      read(ctmp,*) rlat
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
         read(15,rec=iy) (rdat(ix,iy), ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      ixpnt=int((rlon-plonmin)/(plonmax-plonmin)*real(nx)+0.5)
      iypnt=int((platmax-rlat)/(platmax-platmin)*real(ny)+0.5)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      write(*,*) rdat(ixpnt,iypnt)
c
      end

