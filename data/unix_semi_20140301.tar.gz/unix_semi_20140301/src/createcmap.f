      program createcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   create 144x72 array
con   31/May/2002
cby   nhanasaki
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer          nx
      integer          ny
      real             pmis
      parameter       (nx=144)
      parameter       (ny=72)
      parameter       (pmis=1.0E20)
c index
      integer          ix
      integer          iy
c temporary
      character*128    ctmp
c function
      integer          iargc
c in
      real             rdat
c out
      real             rout(144,72)
c file
      character*128    cofname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if (iargc().ne.2) then
        write(*,*) 'Usage createcmap OutFile Num'
        stop
      end if 
c
      call getarg(1,cofname)
      call getarg(2,ctmp)
      read(ctmp,*) rdat
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      do iy=1,ny
        do ix=1,nx
          rout(ix,iy) = rdat
        end do
      end do
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write 
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(16,file=cofname,access='DIRECT',recl=nx*4)
      do iy=1,ny
          write(16,rec=iy) (rout(ix,iy),ix=1,nx)
      end do
      close(16)
c
      end
