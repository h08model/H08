      program rplscmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   replace data that meet a condition
cby   nhanasaki
con   13th Aug 2002
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx 
      integer           ny
      parameter        (nx=144)
      parameter        (ny=72)
c index
      integer           ix
      integer           iy               !! matrix coordinate
c temporary
      character*128     ctmp             !! dummy
c function
      integer           iargc
c in
      real              rdat(nx,ny)      !! matrix data
c local
      integer           icnt             !! counter
      real              rnum             !! number to pickup
      real              rrpl             !! number to replace
      character*128     csgn             !! option
c file
      character*128     cifname          !! Input File NAME
      character*128     cofname

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.5) then
        write(*,*) 'Usage: rplscmap Infile Sgn Real_num Rpls_num Outfil'
        write(*,*) 'Sign:  eq ne lt le gt ge'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,csgn)
      call getarg(3,ctmp)
      read(ctmp,*) rnum
      call getarg(4,ctmp)
      read(ctmp,*) rrpl
      call getarg(5,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read dat 
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy), ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write results
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      icnt=0
      if(csgn.eq.'ne')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).ne.rnum)then
              rdat(ix,iy)=rrpl
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data not equal to ', rnum
      else if(csgn.eq.'le')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).le.rnum)then
              rdat(ix,iy)=rrpl
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data less equal to ', rnum
      else if(csgn.eq.'lt')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).lt.rnum)then
              rdat(ix,iy)=rrpl
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data less than ', rnum
      else if(csgn.eq.'ge')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).ge.rnum)then
              rdat(ix,iy)=rrpl
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data greater equal to ', rnum
      else if(csgn.eq.'gt')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).gt.rnum)then
              rdat(ix,iy)=rrpl
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data greater than ', rnum
      else if(csgn.eq.'eq')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).eq.rnum)then
              rdat(ix,iy)=rrpl
              icnt=icnt+1
            end if
          end do
        end do
        write(*,*) 'The file has',icnt,' data equal to ',rnum
      else
        write(*,*) 'Sign',csgn,'is not valid. Abort.'
        stop
      end if
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Write
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      open(16,file=cofname,access='direct',recl=nx*4)
      do iy=1,ny
        write(16,rec=iy) (rdat(ix,iy), ix=1,nx)
      end do
      close(16)      
c
      end
