      program sumcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   summation of an array
cby   nhanasaki
con   20th Jul 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx
      integer           ny
      parameter        (nx=144)
      parameter        (ny=72)
c index
      integer           ix
      integer           iy
c temporary
      character*128     ctmp           !! dummy
c function
      integer           iargc
c in
      real              rdat(nx,ny)     !! matrix DATA
c out
      real              rsum
c file
      character*128     cifname          !! Input File NAME
c postpone
      real              rmiss
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.2) then
        write(*,*) 'Usage: sumcmap INBIN miss'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,ctmp)
      read(ctmp,*) rmiss
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read data
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy), ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      rsum=0
c
      do iy=1,ny
        do ix=1,nx
          if(rdat(ix,iy).ne.rmiss)then
            rsum=rsum+rdat(ix,iy)
          end if
        end do
      end do
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write result
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      write(*,*) rsum
c
      end

