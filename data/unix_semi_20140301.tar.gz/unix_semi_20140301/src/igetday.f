      integer function igetday(iyear,imon)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   count number of days in month
cby   nhanasaki
con   20th Dec 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c in
      integer           iyear
      integer           imon
c local
      integer           ifeb
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation for months except February
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(imon.eq.4.or.imon.eq.6.or.imon.eq.9.or.imon.eq.11)then
        igetday=30
      else
        igetday=31
      end if
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation for February
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(imon.eq.2.or.imon.eq.0)then
        if(mod(iyear,4).eq.0)then
          ifeb=29
          if(mod(iyear,100).eq.0)then
            ifeb=28
            if(mod(iyear,400).eq.0)then
              ifeb=29
            end if
          end if
        else
          ifeb=28
        end if
      end if
c fix
      if(iyear.eq.0)then
        ifeb=28
      end if
c fix
      if(imon.eq.2)then
        igetday=ifeb
      else if(imon.eq.0)then
        igetday=ifeb+337
      end if
c
      end
