      program findcmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   find value in an array if it meets condition
cby   nhanasaki
con   13th Aug 2002
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c      
      integer           nx 
      integer           ny
      real              plonmin
      real              plonmax
      real              platmin
      real              platmax
      parameter        (nx=144)
      parameter        (ny=72)
      parameter        (plonmin=-180.0) 
      parameter        (plonmax=180.0) 
      parameter        (platmin=-90.0) 
      parameter        (platmax=90.0) 
c index
      integer           ix
      integer           iy               !! matrix coordinate
c temporary
      character*128     ctmp             !! dummy
c function
      integer           iargc
c in
      real              rdat(nx,ny)      !! matrix data
      character*128     csgn             !! sign
c out
      integer           icnt             !! counter
      real              rnum             !! number to pickup
c file
      character*128     cifname          !! Input File NAME
      character*128     cofname          !! Output File NAME
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.4) then
        write(*,*) 'Usage: findcmap Infile Sign Real_number Outfile'
        write(*,*) 'Sign:  eq ne lt le gt ge'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,csgn)
      call getarg(3,ctmp)
      read(ctmp,*) rnum
      call getarg(4,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read data
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy), ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write results
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      icnt=0
      if(csgn.eq.'ne')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).ne.rnum)then
              write(*,*)
     $        plonmin+(plonmax-plonmin)/real(nx)*(real(ix)-0.5),
     $        platmax-(platmax-platmin)/real(ny)*(real(iy)-0.5),
     $        rdat(ix,iy)
              icnt=icnt+1
            else
              rdat(ix,iy)=0.0
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data not equal to ', rnum
      else if(csgn.eq.'le')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).le.rnum)then
              write(*,*) 
     $        plonmin+(plonmax-plonmin)/real(nx)*(real(ix)-0.5),
     $        platmax-(platmax-platmin)/real(ny)*(real(iy)-0.5),
     $        rdat(ix,iy)
              icnt=icnt+1
            else
              rdat(ix,iy)=0.0
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data less equal to ', rnum
      else if(csgn.eq.'lt')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).lt.rnum)then
              write(*,*) 
     $        plonmin+(plonmax-plonmin)/real(nx)*(real(ix)-0.5),
     $        platmax-(platmax-platmin)/real(ny)*(real(iy)-0.5),
     $        rdat(ix,iy)
              icnt=icnt+1
            else
              rdat(ix,iy)=0.0
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data less than ', rnum
      else if(csgn.eq.'ge')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).ge.rnum)then
              write(*,*) 
     $        plonmin+(plonmax-plonmin)/real(nx)*(real(ix)-0.5),
     $        platmax-(platmax-platmin)/real(ny)*(real(iy)-0.5),
     $        rdat(ix,iy)
              icnt=icnt+1
            else
              rdat(ix,iy)=0.0
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data greater equal to ', rnum
      else if(csgn.eq.'gt')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).gt.rnum)then
              write(*,*) 
     $        plonmin+(plonmax-plonmin)/real(nx)*(real(ix)-0.5),
     $        platmax-(platmax-platmin)/real(ny)*(real(iy)-0.5),
     $        rdat(ix,iy)
              icnt=icnt+1
            else
              rdat(ix,iy)=0.0
            end if
          end do
        end do
        write(*,*) 'The file has ',icnt,' data greater than ', rnum
      else if(csgn.eq.'eq')then
        do iy=1,ny
          do ix=1,nx
            if(rdat(ix,iy).eq.rnum)then
              write(*,*) 
     $        plonmin+(plonmax-plonmin)/real(nx)*(real(ix)-0.5),
     $        platmax-(platmax-platmin)/real(ny)*(real(iy)-0.5),
     $        rdat(ix,iy)
              icnt=icnt+1
            else
              rdat(ix,iy)=0.0
            end if
          end do
        end do
        write(*,*) 'The file has',icnt,' data equal to ',rnum
      else
        write(*,*) 'Sign ',csgn,' is not valid. Abort.'
        stop
      end if
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      open(16,file=cofname,access='direct',recl=nx*4)
      do iy=1,ny
        write(16,rec=iy) (rdat(ix,iy), ix=1,nx)
      end do
      close(16)      
c
      end
