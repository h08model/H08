      program mulmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   multiple two 144x72 arrays
cby   nhanasaki
con   31/May/2002
cat   IIS, UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer          nx
      integer          ny
      parameter       (nx=144)
      parameter       (ny=72)
c index
      integer          ix
      integer          iy
c temporary
      character*128    ctmp
c function
      integer          iargc
c in
      real             rdat1(nx,ny)
      real             rdat2
c out
      real             rout(nx,ny)
c file
      character*128    cifname
      character*128    cofname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get argument
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if (iargc().ne.3) then
        write(6,*) 'Usage: mulcmap Infile real_number Outfile'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,ctmp)
      read(ctmp,*) rdat2
      call getarg(3,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read file
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='DIRECT',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat1(ix,iy),ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calculation
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      do ix=1,nx
        do iy=1,ny
          rout(ix,iy)=rdat1(ix,iy)*rdat2
        end do
      end do
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write Result
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(16,file=cofname,access='DIRECT',recl=nx*4)
      do iy=1,ny
        write(16,rec=iy) (rout(ix,iy),ix=1,nx)
      end do
      close(16)
c
      end            
