      program cmap2xyz
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   convert binary (144x72) to ascii in lon,lat,data format
cby   nhanasaki
con   30th/May/2002
cat   IIS, UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx
      integer           ny
      real              plonmin
      real              plonmax
      real              platmin
      real              platmax
      parameter        (nx=144)
      parameter        (ny=72)
      parameter        (plonmin=-180.0) 
      parameter        (plonmax=180.0) 
      parameter        (platmin=-90.0) 
      parameter        (platmax=90.0) 
c index
      integer           ix
      integer           iy
c function
      integer           iargc
c in
      real              rdat(nx,ny)
c out
      real              rlon(nx)
      real              rlat(ny)
c file
      character*128     cifname
      character*128     cofname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if (iargc().ne.2) then
        write(*,*) 'Usage: cmap2xyz INBIN OUTASC'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='direct',status='old',recl=nx*4)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy),ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calclulation
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c longtitude
      do ix=1,nx
        rlon(ix)=plonmin+(plonmax-plonmin)/real(nx)*(real(ix)-0.5)
      end do
c latitude
      do iy=1,ny
        rlat(iy)=platmax-(platmax-platmin)/real(ny)*(real(iy)-0.5)
      end do
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write Data
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(16, file=cofname, access='sequential')
      do iy=1,ny
        do ix=1,nx
          write(16,*) rlon(ix), rlat(iy), rdat(ix,iy)
        end do
      end do
      close(16)
c
      end

