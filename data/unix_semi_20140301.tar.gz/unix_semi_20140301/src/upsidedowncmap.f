      program upsidedowncmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   upsidedown an array
cby   nhanasaki
con   26th Oct 2002
cat   IIS, UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx
      integer           ny
      parameter        (nx=360)
      parameter        (ny=180)
c index
      integer           ix
      integer           iy
c in
      real              rdat(nx,ny)
c out
      real              rout(nx,ny)
c file
      character*128     cifname
      character*128     cofname
c function
      integer           iargc
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get argumebnts
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.2)then
        write(*,*) 'Usage: upsidedowncmap INBIN OUTBIN'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname,access='direct',status='old',recl=4*nx)
      do iy=1,ny
        read(15,rec=iy) (rdat(ix,iy),ix=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Calc
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      do iy=1,ny
        do ix=1,nx
          rout(ix,iy) = rdat(ix,ny-iy+1)
        end do
      end do
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(16,file=cofname,access='direct',recl=4*nx)
      do iy=1,ny
        write(16,rec=iy) (rout(ix,iy),ix=1,nx)
      end do
      close(16)
c
      end



