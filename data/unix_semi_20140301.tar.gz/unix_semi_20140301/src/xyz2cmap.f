      program xyz2cmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto        convert ascii in (lon,lat,data) format  to binary
cby        nhanasaki
con        30th/May/2002
cat        IIS, UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c parameter
      integer           nx
      integer           ny
      real              plonmin
      real              plonmax
      real              platmin
      real              platmax
      parameter        (nx=144)
      parameter        (ny=72)
      parameter        (plonmin=-180)
      parameter        (plonmax=180)
      parameter        (platmin=-90)
      parameter        (platmax=90)
c index 
      integer           ix
      integer           iy
c temporary
      real              rtmp
c function
      integer           iargc
c in
      real              rlon
      real              rlat
      real              rdat
c out
      real              rout(nx,ny)
      integer           icnt
c file
      character*128     cifname
      character*128     cofname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if (iargc().ne.2) then
        write(6,*) 'Usage: xyz2cmap Infile Outfile'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15, file=cifname, access='sequential',status='old')
 10   read(15,*,end=20) rlon, rlat, rdat

c debug kametani ccccccccccccccccccccccccccccccccccccccccccccccccccccc

      if (rlon .gt. 180.0) then
         rlon = rlon - 360.0
      endif
      if (rlon .lt. -180.0) then
         rlon = rlon + 360.0
      endif

cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      
      ix=int((rlon-plonmin)/(plonmax-plonmin)*real(nx)+0.5)
      iy=int((platmax-rlat)/(platmax-platmin)*real(ny)+0.5)
      rout(ix,iy)=rdat
      icnt=icnt+1
      goto 10
 20   close(15)
      write(*,*) 'The file has',icnt,'data'
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(16,file=cofname,access='direct',recl=nx*4)
      do iy=1,ny
        write(16,rec=iy) (rout(ix,iy),ix=1,nx)
      end do
      close(16)
c
      end

