      program nofday
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   count number of days in a month
cby   nhanasaki
con   20th Dec 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      implicit none
c in
      integer           iyear
      integer           imon
c out
      integer           inofday
c local
      character*128     ctmp
      integer           iflg
c sys
      integer           iargc
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      if(iargc().ne.2)then
        write(*,*) 'ERROR:nofday <year> <mon>'
        stop
      end if
c
      call getarg(1,ctmp)
      read(ctmp,*) iyear
      call getarg(2,ctmp)
      read(ctmp,*) imon
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Calculation for months except February
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      if(imon.eq.4.or.imon.eq.6.or.imon.eq.9.or.imon.eq.11)then
        inofday=30
      else
        inofday=31
      end if
c
      if(imon.eq.0)then
        iflg=1
        imon=2
      else
        iflg=0
      end if
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Calculation for February
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
      if(imon.eq.2)then
        if(mod(iyear,4).eq.0)then
          inofday=29
          if(mod(iyear,100).eq.0)then
            inofday=28
            if(mod(iyear,400).eq.0)then
              inofday=29
            end if
          end if
        else
          inofday=28
        end if
      end if
c fix
      if(iyear.eq.0.and.imon.eq.2)then
        inofday=28
      end if
      if(iflg.eq.1)then
        inofday=inofday+337
      end if
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc 
c Write results
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      write(*,*) inofday
c
      end
