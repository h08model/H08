1	cd wildcard
2	rm *1*
3	rm *
4	cp /Users/guest/pub/unix_semi/lesson2/wildcard/* .
