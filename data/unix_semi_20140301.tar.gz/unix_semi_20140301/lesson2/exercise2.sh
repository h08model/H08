ls -l > temp.txt
wc temp.txt

ls -l | wc
