      program asc2cmap
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
cto   convert ascii file to binary file
cby   nhanasaki
con   13th Oct 2003
cat   IIS,UT
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      integer       nx,ny
      parameter    (nx=144,ny=72)
c
      integer       i,j
      real          rdata(nx,ny)
      character*128 cifname
      character*128 cofname
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Get arguments
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      if(iargc().ne.2) then
        write(*,*) 'Usage: asc2cmap Infile Outfile'
        stop
      end if
c
      call getarg(1,cifname)
      call getarg(2,cofname)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Read data
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(15,file=cifname)
      do j=1,ny
        read(15,*) (rdata(i,j), i=1,nx)
      end do
      close(15)
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
c Write data
cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
      open(16,file=cofname,access='direct',recl=nx*4)
      do j=1,ny
        write(16,rec=j) (rdata(i,j), i=1,nx)
      end do
      close(16)
c
      end
