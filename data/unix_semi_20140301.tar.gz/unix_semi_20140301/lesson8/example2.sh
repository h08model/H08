#!/bin/sh
############################################################
YEAR=2005
MONS="01 02 03 04 05 06 07 08 09 10 11 12"
BIRTHMON=02
BIRTHDAY=28
############################################################
for MON in $MONS; do
  DAY=1
  EDAY=`nofday $MON $YEAR`
  while [ $DAY -le $EDAY ]; do
    if [ $MON = $BIRTHMON -a $DAY = $BIRTHDAY ]; then
      echo $MON $DAY "Happy birth day!"
    else
      echo $MON $DAY
    fi
    DAY=`expr $DAY + 1`
  done
done