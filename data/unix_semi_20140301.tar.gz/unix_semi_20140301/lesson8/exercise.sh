#!/bin/sh
############################################################
#to   convert CMAP original file to binary file
#by   nhanasaki
#on   15th Mar 2004
#at   IIS,UT
############################################################
# Arguments
############################################################
SYEAR=1979                 # start year
EYEAR=1979                 # end year
#EYEAR=2002                 
VER=203                    # version
INDIR=../dat_org/          # input directory
OUTDIR=../dat_bin/         # output directory
TMPFILE=temp.xyz           # temporary file
BIN=../src/
############################################################
#
############################################################
YEAR=$SYEAR                        # put initial value to YEAR
while [ $YEAR -le $EYEAR ]; do     # iterate from SYEAR to EYEAR
  if [ $YEAR -le 1999 ]; then      # convert 4 column YEAR to 2 column YR
    YR=`expr $YEAR - 1900`
  else
    YR=`expr $YEAR - 2000`
  fi
  YR=`echo $YR | awk '{printf("%2.2d",$1)}'`    # convert 1 to 01, 2 to 02 etc
  INFILE=${INDIR}cmap_mon_v0${VER}_${YR}.txt     # set input file
  gunzip ${INFILE}.gz                           # uncompress file
  for MON in 01 02 03 04 05 06 07 08 09 10 11 12; do    # monthly iteration
    OUTFILE=${OUTDIR}CMAP${VER}_${YEAR}${MON}00.cmap     # set output file
    awk '($2=='"${MON}"'){printf("%9.3f%9.3f%9.3f\n",$4,$3,$5)}' $INFILE > $TMPFILE                                            # extract data for the month
    ${BIN}xyz2cmap $TMPFILE $OUTFILE                  # convert ascii to binary
  done
  gzip ${INFILE}                                # compress input file
  YEAR=`expr $YEAR + 1`                         # add 1 to YEAR for next loop
done