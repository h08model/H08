#!/bin/sh
############################################################
#ex   Input/Output File
#on    31/May/2002
#by    nhanasaki
#at    IIS,UT
############################################################
# Define File Names
############################################################
DATFILE=./data.xyz      #data file (input)
#DATAFILE=./cmap_mon_v0203_79.txt
PSFILE=./image.3.eps     #image file (output)
GRDFILE=./grd           #temporary file
CPTFILE=./grad.3.cpt      #color paltette table file
############################################################
# Define Mapping Area
############################################################
XMIN=20.00               #Horizontal minimum [degree]
XMAX=80.00             #Horizontal maximum [degree]
YMIN=20.00             #Vertical minimum [degree]
YMAX=50.00              #Vertical maximum [degree]
XWID=21.0               #Width of image [cm]
YWID=10.5               #Height of image [cm]
DXa=10.0		#a:Horizontal Anotation Interval [degree]
DXf=10.0		#f:Horizontal Frame Interval [degree]
DXg=5.0		#G:Horizontal Grid Interval [degree]
DYa=10.0		#a:Vertical Anotation Interval [degree]
DYf=10.0		#f:Vertical Frame Interval [degree]
DYg=5.0		#g:Vertical Grid Interval [degree]
D=2.5                   #grid size
############################################################
# Short Cuts for Options
############################################################
RFLAG="-R${XMIN}/${XMAX}/${YMIN}/${YMAX}"
JFLAG="-JX${XWID}d/${YWID}d"
BFLAG="-Ba${DXa}f${DXf}g${DXg}:Longitude:/a${DYa}f${DYf}g${DYg}:Latitude:neWS"
############################################################
#---Jobs
############################################################
#awk '($2==1){print $4, $3, $5}' $DATAFILE | \
#GMT xyz2grd     $RFLAG -G$GRDFILE -I${D}/${D} -F
GMT xyz2grd     $RFLAG -G$GRDFILE -I${D}/${D} -F $DATFILE
#
GMT psbasemap   $RFLAG $JFLAG $BFLAG -X5.0 -Y5.0         -K  > ./$PSFILE 
GMT grdimage -O $RFLAG $JFLAG $GRDFILE -C$CPTFILE        -K >> ./$PSFILE 
GMT pscoast  -O $RFLAG $JFLAG -Di -W5 -N1 -I1 -S0/0/0    -K >> ./$PSFILE
GMT psscale  -O -C$CPTFILE -D5.0/-1.5/8/0.5h -L          -K >> ./$PSFILE
GMT pstext   -O $RFLAG $JFLAG -N                     << EOF >> ./$PSFILE
50  55 24 0.0 1 6 Iran Jan 1979
50  15 12 0.0 1 6 [mm/day]
EOF
############################################################
# Comments for Options
############################################################
#-R: Option specifies region of interest
#-J: Option for mapping projection (JX: projection type)
#-B: Option for frame
#-O: Option for "Omit Header" i.e. following GMT command
#-K: Option for "Omit Trailer" i.e. GMT commands follow on
#
#--GMT psbasemap
#
#draw basemap
#-X: Shift plot origin x-direction [cm]
#-Y: Shift plot origin y-direction [cm]
#
#--GMT xyz2grd
#
#convert ASCII-xyz-data into binary-grid-data
#
#--GMT gridimage
#
#conert binary-grid-data into colored mosaic image
#
#--GMT pscoast
#
#draw coastline
#-D: Resolution
#-W: Boldness
#-N: National Border
#-I: Rivers
#
#--GMT psscale
#
#draw color bar
#-D: Place to put
#-L: Give Equal size rectangular
#
#--GMT pstext
#
#write text between EOFs
#-N: Do not clip
#{horizontal[degree]/vertical[degree]/Point/Angle/Font?/Place?/Text}