#!/bin/sh
############################################################
# Population
############################################################

# 0mm/year =< Precipitation < 50mm/year

maskcmap pop.cmap          prc.cmap ge  0 temp.pop.ge0.cmap      > /dev/null
maskcmap temp.pop.ge0.cmap prc.cmap lt 50 temp.pop.ge0.lt50.cmap > /dev/null
POP_0_50=`sumcmap  temp.pop.ge0.lt50.cmap 0`

# 50mm/year =< Precipitation < 100mm/year

maskcmap pop.cmap            prc.cmap ge  50 temp.pop.ge50.cmap  > /dev/null
maskcmap temp.pop.ge50.cmap  prc.cmap lt 100 temp.pop.ge50.lt100.cmap  > /dev/null
POP_50_100=`sumcmap  temp.pop.ge50.lt100.cmap 0`

# 100mm/year =< Precipitation < 500mm/year

maskcmap pop.cmap             prc.cmap ge 100 temp.pop.ge100.cmap  > /dev/null
maskcmap temp.pop.ge100.cmap  prc.cmap lt 500 temp.pop.ge100.lt500.cmap  > /dev/null
POP_100_500=`sumcmap  temp.pop.ge100.lt500.cmap 0`

# 500mm/year =< Precipitation < 1000mm/year

maskcmap pop.cmap              prc.cmap ge 500  temp.pop.ge500.cmap  > /dev/null
maskcmap temp.pop.ge500.cmap   prc.cmap lt 1000 temp.pop.ge500.lt1000.cmap  > /dev/null
POP_500_1000=`sumcmap  temp.pop.ge500.lt1000.cmap 0`

# 1000mm/year =< Precipitation < 2000mm/year

maskcmap pop.cmap               prc.cmap ge 1000 temp.pop.ge1000.cmap  > /dev/null
maskcmap temp.pop.ge1000.cmap   prc.cmap lt 2000 temp.pop.ge1000.lt2000.cmap  > /dev/null
POP_1000_2000=`sumcmap  temp.pop.ge1000.lt2000.cmap 0`

# 2000mm/year =< Precipitation

maskcmap pop.cmap               prc.cmap ge 2000 temp.pop.ge2000.cmap  > /dev/null
POP_2000=`sumcmap  temp.pop.ge2000.cmap 0`

# Total

POP_TOTAL=`sumcmap pop.cmap 0`

############################################################
# Land Area
############################################################

# 0mm/year =< Precipitation < 50mm/year

maskcmap lndara.cmap     prc.cmap ge  0 temp.area.ge0.cmap  > /dev/null
maskcmap temp.area.ge0.cmap   prc.cmap lt 50 temp.area.ge0.lt50.cmap  > /dev/null
LAND_0_50=`sumcmap  temp.area.ge0.lt50.cmap 0`

# 50mm/year =< Precipitation < 100mm/year

maskcmap lndara.cmap          prc.cmap ge  50 temp.area.ge50.cmap  > /dev/null
maskcmap temp.area.ge50.cmap  prc.cmap lt 100 temp.area.ge50.lt100.cmap  > /dev/null
LAND_50_100=`sumcmap  temp.area.ge50.lt100.cmap 0`

# 100mm/year =< Precipitation < 500mm/year

maskcmap lndara.cmap          prc.cmap ge 100 temp.area.ge100.cmap  > /dev/null
maskcmap temp.area.ge100.cmap prc.cmap lt 500 temp.area.ge100.lt500.cmap  > /dev/null
LAND_100_500=`sumcmap  temp.area.ge100.lt500.cmap 0`

# 500mm/year =< Precipitation < 1000mm/year

maskcmap lndara.cmap          prc.cmap ge 500  temp.area.ge500.cmap  > /dev/null
maskcmap temp.area.ge500.cmap prc.cmap lt 1000 temp.area.ge500.lt1000.cmap  > /dev/null
LAND_500_1000=`sumcmap  temp.area.ge500.lt1000.cmap 0`

# 1000mm/year =< Precipitation < 2000mm/year

maskcmap lndara.cmap           prc.cmap ge 1000 temp.area.ge1000.cmap  > /dev/null
maskcmap temp.area.ge1000.cmap prc.cmap lt 2000 temp.area.ge1000.lt2000.cmap  > /dev/null
LAND_1000_2000=`sumcmap  temp.area.ge1000.lt2000.cmap 0`

# 2000mm/year =< Precipitation

maskcmap lndara.cmap       prc.cmap ge 2000 temp.area.ge2000.cmap  > /dev/null
LAND_2000=`sumcmap  temp.area.ge2000.cmap 0`

# Total

LAND_TOTAL=`sumcmap lndara.cmap 0`

############################################################
# 
############################################################
echo
echo 'Precip' 'Pop(10^6)' 'Area(10^6km2)' | awk '{printf("%12s,%12s,%12s\n",$1,$2,$3)}'
echo '0-50' $POP_0_50 $LAND_0_50 | awk '{printf("%12s,%12.2f,%12.2f\n",$1,$2/1000/1000,$3/1000/1000)}'
echo '50-100' $POP_50_100 $LAND_50_100 | awk '{printf("%12s,%12.2f,%12.2f\n",$1,$2/1000/1000,$3/1000/1000)}'
echo '100-500' $POP_100_500 $LAND_100_500 | awk '{printf("%12s,%12.2f,%12.2f\n",$1,$2/1000/1000,$3/1000/1000)}'
echo '500-1000' $POP_500_1000 $LAND_500_1000 | awk '{printf("%12s,%12.2f,%12.2f\n",$1,$2/1000/1000,$3/1000/1000)}'
echo '1000-2000' $POP_1000_2000 $LAND_1000_2000 | awk '{printf("%12s,%12.2f,%12.2f\n",$1,$2/1000/1000,$3/1000/1000)}'
echo '2000-' $POP_2000 $LAND_2000 | awk '{printf("%12s,%12.2f,%12.2f\n",$1,$2/1000/1000,$3/1000/1000)}'
echo 'Total' $POP_TOTAL $LAND_TOTAL | awk '{printf("%12s,%12.2f,%12.2f\n",$1,$2/1000/1000,$3/1000/1000)}'


