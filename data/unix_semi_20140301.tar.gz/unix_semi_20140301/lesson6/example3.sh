#!/bin/sh
############################################################

############################################################
for DAT in pop lndara; do
  JOB=1
  while [ $JOB -le 6 ]; do
    if   [ $JOB -eq 1 ]; then
      LL=0; UL=50
    elif [ $JOB -eq 2 ]; then
      LL=50; UL=100
    elif [ $JOB -eq 3 ]; then
      LL=100; UL=500
    elif [ $JOB -eq 4 ]; then
      LL=500; UL=1000
    elif [ $JOB -eq 5 ]; then
      LL=1000; UL=2000
    elif [ $JOB -eq 6 ]; then
      LL=2000; UL=99999
    fi
    maskcmap ${DAT}.cmap              prc.cmap ge ${LL} temp.${DAT}.ge${LL}.cmap
    maskcmap temp.${DAT}.ge${LL}.cmap prc.cmap lt ${UL} temp.${DAT}.ge${LL}.lt${UL}cmap
    sumcmap  temp.${DAT}.ge${LL}.lt${UL}cmap 0
    JOB=`expr $JOB + 1`
  done
done