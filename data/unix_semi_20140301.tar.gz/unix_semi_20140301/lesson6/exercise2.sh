############################################################
# Population
############################################################

echo --- Population ---

# 0mm/year =< Precipitation < 50mm/year

maskcmap pop.cmap          prc.cmap ge  0 temp.pop.ge0.cmap
maskcmap temp.pop.ge0.cmap prc.cmap lt 50 temp.pop.ge0.lt50.cmap
sumcmap  temp.pop.ge0.lt50.cmap 0

# 50mm/year =< Precipitation < 100mm/year

maskcmap pop.cmap            prc.cmap ge  50 temp.pop.ge50.cmap
maskcmap temp.pop.ge50.cmap  prc.cmap lt 100 temp.pop.ge50.lt100.cmap
sumcmap  temp.pop.ge50.lt100.cmap 0

# 100mm/year =< Precipitation < 500mm/year

maskcmap pop.cmap             prc.cmap ge 100 temp.pop.ge100.cmap
maskcmap temp.pop.ge100.cmap  prc.cmap lt 500 temp.pop.ge100.lt500.cmap
sumcmap  temp.pop.ge100.lt500.cmap 0

# 500mm/year =< Precipitation < 1000mm/year

maskcmap pop.cmap              prc.cmap ge 500  temp.pop.ge500.cmap
maskcmap temp.pop.ge500.cmap   prc.cmap lt 1000 temp.pop.ge500.lt1000.cmap
sumcmap  temp.pop.ge500.lt1000.cmap 0

# 1000mm/year =< Precipitation < 2000mm/year

maskcmap pop.cmap               prc.cmap ge 1000 temp.pop.ge1000.cmap
maskcmap temp.pop.ge1000.cmap   prc.cmap lt 2000 temp.pop.ge1000.lt2000.cmap
sumcmap  temp.pop.ge1000.lt2000.cmap 0

# 2000mm/year =< Precipitation

maskcmap pop.cmap               prc.cmap ge 2000 temp.pop.ge2000.cmap
sumcmap  temp.pop.ge2000.cmap 0

# Total

sumcmap pop.cmap 0

############################################################
# Land Area
############################################################

echo --- Land area ---

# 0mm/year =< Precipitation < 50mm/year

maskcmap lndara.cmap     prc.cmap ge  0 temp.area.ge0.cmap
maskcmap temp.area.ge0.cmap   prc.cmap lt 50 temp.area.ge0.lt50.cmap
sumcmap  temp.area.ge0.lt50.cmap 0

# 50mm/year =< Precipitation < 100mm/year

maskcmap lndara.cmap          prc.cmap ge  50 temp.area.ge50.cmap
maskcmap temp.area.ge50.cmap  prc.cmap lt 100 temp.area.ge50.lt100.cmap
sumcmap  temp.area.ge50.lt100.cmap 0

# 100mm/year =< Precipitation < 500mm/year

maskcmap lndara.cmap          prc.cmap ge 100 temp.area.ge100.cmap
maskcmap temp.area.ge100.cmap prc.cmap lt 500 temp.area.ge100.lt500.cmap
sumcmap  temp.area.ge100.lt500.cmap 0

# 500mm/year =< Precipitation < 1000mm/year

maskcmap lndara.cmap          prc.cmap ge 500  temp.area.ge500.cmap
maskcmap temp.area.ge500.cmap prc.cmap lt 1000 temp.area.ge500.lt1000.cmap
sumcmap  temp.area.ge500.lt1000.cmap 0

# 1000mm/year =< Precipitation < 2000mm/year

maskcmap lndara.cmap           prc.cmap ge 1000 temp.area.ge1000.cmap
maskcmap temp.area.ge1000.cmap prc.cmap lt 2000 temp.area.ge1000.lt2000.cmap
sumcmap  temp.area.ge1000.lt2000.cmap 0

# 2000mm/year =< Precipitation

maskcmap lndara.cmap       prc.cmap ge 2000 temp.area.ge2000.cmap
sumcmap  temp.area.ge2000.cmap 0

# Total

sumcmap lndara.cmap 0