subcmap        CMAP203_19870000.cmap CMAP203_19880000.cmap dif.cmap
ratcmap        dif.cmap              CMAP203_19870000.cmap rat.cmap
cmap2eps       rat.cmap              rat.cpt               rat.eps
