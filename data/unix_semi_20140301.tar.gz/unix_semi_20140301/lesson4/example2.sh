mon2yearcmap   ./ CMAP 203_ 1987 1988 .cmap
subcmap        CMAP203_19870000.cmap CMAP203_19880000.cmap dif.cmap
cmap2eps       dif.cmap              dif.cpt               dif.eps
